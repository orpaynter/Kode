import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  
  // Tauri-specific configuration
  server: {
    port: 1420,
    strictPort: true,
  },
  // Explicitly define the base to ensure assets are properly referenced in the bundled app
  base: './',
})
